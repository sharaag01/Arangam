package com.think42lab.arangam;

/**
 * Created by Lenovo on 12/9/2016.
 */

public class Program {
    private String accompanists;

    public Program() {

    }

    public Program(String accompanists) {
        this.accompanists = accompanists;
    }

    public String getAccompanists() {
        return accompanists;
    }

    public void setAccompanists(String accompanists) {
        this.accompanists = accompanists;
    }
}