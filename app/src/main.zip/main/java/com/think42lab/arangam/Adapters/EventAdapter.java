package com.think42lab.arangam.Adapters;

/**
 * Created by krishna on 12/8/16.
 */

public class EventAdapter {
}
