package com.think42lab.arangam;

public interface RequestCallBack {
    void success(String response);

    void fail();
}
