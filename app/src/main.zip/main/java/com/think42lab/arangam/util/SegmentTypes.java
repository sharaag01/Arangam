package com.think42lab.arangam.util;

/**
 * Created by prasath on 20/12/16.
 */

public class SegmentTypes {
    public static String TYPE_CONCERTS = "1";
    public static String TYPE_LEGDEM = "2";
}
