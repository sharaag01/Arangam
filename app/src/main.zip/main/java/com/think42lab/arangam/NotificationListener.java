package com.think42lab.arangam;

/**
 * Created by Nishanth on 12/11/2016.
 */
public interface NotificationListener {
    public void notifyFavorites(int count);
}
